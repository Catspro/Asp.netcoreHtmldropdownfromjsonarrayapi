﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace DropDownTest.Models
{
    public class DDLOptions
    {
        public int Id { get; set; }
        public string CityName { get; set; }

    }

    public class EmpModel
    {
        [Display(Name = "Select City")]
        public string City { get; set; }
    }
}



