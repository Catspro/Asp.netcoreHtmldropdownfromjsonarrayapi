﻿using DropDownTest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Rest;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DropDownTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public JsonResult retJson()
        {
            var value = "{\"result\":[{\"ID\":\"001\",\"Name\":\"EurasianCollared-Dove\"},{\"ID\":\"002\",\"Name\":\"BaldEagle\"},{\"ID\":\"003\",\"Name\":\"Cooper'sHawk\"},{\"ID\":\"004\",\"Name\":\"Bell'sSparrow\"},{\"ID\":\"017\",\"Name\":\"SnailKite\"},{\"ID\":\"018\",\"Name\":\"White-tailedHawk\"}]}";
            JObject json = JObject.Parse(value);

            return Json(json["result"].ToString());
        }
        public JsonResult NameList()
        {

            string response = "";
            string url = "https://www.encodedna.com/library/sample.json";
            using (var client = new WebClient())
            {
                client.Headers.Add("content-type", "application/json");
                 response = client.DownloadString(url);
            }

            return Json(response);
        }

        //Return json list of cities  
        [HttpGet]
        public JsonResult CityList()
        {
            List<DDLOptions> obj = new List<DDLOptions>()
            {
                new DDLOptions {Id=1, CityName="Latur" },
                new DDLOptions {Id=2, CityName="Pune" },
                new DDLOptions {Id=4, CityName="Mumbai"},
                new DDLOptions {Id=5, CityName="New Delhi" }
            }.ToList();

            return Json(obj);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
